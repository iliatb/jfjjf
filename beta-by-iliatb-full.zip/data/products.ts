export const products = [
  {
    title: "Футболка Beta",
    image: "/shirt.jpg",
    price: 29.99,
  },
  {
    title: "Толстовка iliATB",
    image: "/hoodie.jpg",
    price: 59.99,
  },
  {
    title: "Кепка фирменная",
    image: "/cap.jpg",
    price: 19.99,
  },
];