"use client";
import { useCart } from "@/context/CartContext";

type ProductProps = {
  title: string;
  image: string;
  price: number;
};

export default function ProductCard({ title, image, price }: ProductProps) {
  const { addToCart } = useCart();

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-md p-4 transition-transform hover:scale-105">
      <img src={image} alt={title} className="w-full h-48 object-cover rounded-lg" />
      <h3 className="mt-2 text-xl font-semibold text-gray-800 dark:text-white">{title}</h3>
      <p className="text-lg text-green-600 font-bold">${price.toFixed(2)}</p>
      <button
        onClick={() => addToCart({ title, price })}
        className="mt-3 w-full bg-blue-600 text-white py-2 rounded-xl hover:bg-blue-700 transition"
      >
        В корзину
      </button>
    </div>
  );
}