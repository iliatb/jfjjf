"use client";
import { useCart } from "@/context/CartContext";

export default function CartIcon() {
  const { cart } = useCart();
  return (
    <div className="relative">
      🛒
      <span className="absolute -top-2 -right-2 text-xs bg-red-600 text-white rounded-full w-5 h-5 flex items-center justify-center">
        {cart.length}
      </span>
    </div>
  );
}