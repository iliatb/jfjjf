export default function Logo() {
  return (
    <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
      Beta by <span className="text-blue-600 dark:text-blue-400">iliATB</span>
    </h1>
  );
}