import ProductCard from "@/components/ProductCard";
import { products } from "@/data/products";
import ThemeToggle from "@/components/ThemeToggle";
import Logo from "@/components/Logo";
import CartIcon from "@/components/CartIcon";

export default function Page() {
  return (
    <main className="min-h-screen bg-gray-100 dark:bg-gray-900 p-4 text-gray-900 dark:text-white">
      <header className="mb-8 text-center space-y-4">
        <Logo />
        <div className="flex justify-center items-center gap-4">
          <ThemeToggle />
          <CartIcon />
        </div>
      </header>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((p, i) => (
          <ProductCard key={i} {...p} />
        ))}
      </div>
    </main>
  );
}